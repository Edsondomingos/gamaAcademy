declare module '*.md' {
  const content = ''

  export default content
}
