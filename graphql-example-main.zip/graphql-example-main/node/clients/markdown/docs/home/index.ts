import main from './main'

export default {
  main,
}
