export default `
  To know more about the available components, visit the [**Styleguide** page](styleguide.vtex.com).
`
