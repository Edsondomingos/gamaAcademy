import after from './after'
import before from './before'

export default {
  after,
  before,
}
