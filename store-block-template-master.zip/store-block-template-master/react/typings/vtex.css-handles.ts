declare module 'vtex.css-handles'
