import { IOClients } from '@vtex/api'

export class Clients extends IOClients {}
